/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function delete_post(post_id)
{
    // Confirm
    if(confirm('Do you really want to delete this post? This action can not be undone.'))
    {
        $.post({
            url: base_url + 'admin/post/delete',
            data: 'POST_ID=' + post_id,
            success: function(data, text_status, xhr)
            {
                if(data === 'DELETED')
                {
                    alert('Post deleted successfully');

                    // Delete the row corresponding to the post
                    $('#row_' + post_id).remove();
                }
                else
                {
                    alert('There was some error deleting the post. Please try again later');
                }
            },
            error: function(data, text_status, xhr)
            {
                alert('There was some error deleting the post. Please try again later');
            }
        });
    }
}


function delete_addsense(addsense_id)
{
    if(confirm('Do you really want to delete this addsense? This action can not be undone.'))
    {
        $.post({
             url: base_url + 'admin/addsense/delete',
             data: 'ADDSENSE_ID=' + addsense_id,
             success: function(data, text_status, xhr)
            {
                if(data === 'DELETED')
                {
                    alert('Addsense deleted successfully');
                    location.reload();
                }
            },
            error: function(data, text_status, xhr)
            {
                alert('There was some error deleting the Addsense. Please try again later');
            }
        });
    }
}


function delete_pushnotification(pushnotification_id)
{
    if(confirm('Do you really want to delete this pushnotification? This action can not be undone.'))
    {
        $.post({
             url: base_url + 'admin/pushnotification/delete',
             data: 'pushnotification_id=' + pushnotification_id,
             success: function(data, text_status, xhr)
            {
                if(data === 'DELETED')
                {
                    alert('Pushnotification deleted successfully');
                    location.reload();
                }
            },
            error: function(data, text_status, xhr)
            {
                alert('There was some error deleting the Pushnotification. Please try again later');
            }
        });
    }
}
/*
    Ajax upload of images to web page
*/
function upload_images(input_id, progress_bar_id)
{
    // Get the image in a FormData object
    var form_data = new FormData();
    var files = $('#' + input_id).prop('files');
    if(files.length > 0)
    {
        form_data.append('file', files[0]);

        // Disable the upload images button
        $('#upload_img_btn').prop('disabled', true);

        $.post({
            url: base_url + 'admin/media/do_upload/JSON',
            data: form_data,
            success: function(data, text_status, xhr){

                data = JSON.parse(data);
                console.log(data);
                url = data.link;
                id = data.id;

                $('#post_image').prop('src', url);

                // Hide the add new image form
                $('#add_new_image').addClass('hidden');
                $('#display_image').removeClass('hidden');
                $('#image_id').attr('value', id);
            },
            error: function(data, text_status, xhr){
               alert('An error occurred while uploading image. Please try again later.');
            },
            complete: function(){
                $('#upload_img_btn').prop('disabled', false);
                $('#' + progress_bar_id).addClass('hidden');
            },
            contentType: false,
            cache: false,
            processData: false,
            xhr: function(){
                var xhr = $.ajaxSettings.xhr();
                if (xhr.upload) {
                    $('#' + progress_bar_id).removeClass('hidden');
                    xhr.upload.addEventListener('progress', function(event) {
                        var percent = 0;
                        var position = event.loaded || event.position;
                        var total = event.total;
                        if (event.lengthComputable) {
                            percent = Math.ceil(position / total * 100);
                        }
                        //update progressbar
                        $('#' + progress_bar_id + " .status").text(percent +"%");
                    }, true);
                }
                return xhr;
            },
        });
    }
    else
    {
        alert('Please select a file before uploading');
    }    
}

function remove_image(elem_id)
{
    if(window.confirm('Are you sure you want to remove this image?'))
    {
         $('#' + elem_id).prop('src', '');

        // Display the add new image input
        $('#add_new_image').removeClass('hidden');

        // Hide the image display element
        $('#display_image').addClass('hidden');
    }   
}

var file_index = 0;

function show_image(input_elem, target_id)
{
    console.log('inside show image');

    $target = $('#' + target_id);

    // fill fr with image data    
    var arr = $(input_elem).prop('files');

    // Clear the preview images if no image is selected
    if(arr.length == 0)
    {
        $target.html('');
        file_index = 0;
    }
    else
    {
        console.log('Number of files selected: ' + arr.length);

        if(arr.length >= file_index)
        {
            console.log('file index: ' + file_index);

            var fr = new FileReader();

            // when image is loaded, set the src of the image where you want to display it
            fr.onload = function(e)
            {
                var html = '<img src="' + e.target.result + '" />';
                $target.append(html);

                show_image(input_elem, target_id, file_index++);
            };

            fr.readAsDataURL($(arr)[file_index]);
        }   
    }
}

/*
    Clears the selected images on Add Media screen
*/
function clear_selected_images()
{
    $('#file').val('');
    $('#img_preview').html('');
}

/*
    Delete the specific image from the database
*/
function delete_image(image_id)
{
    // Add class to row to show that it is being deleted
    var row = $('#row_' + image_id);
    $(row).addClass('disabled');

    $.post({
        url: 'http://localhost/maliweb/admin/media/delete',
        data: 'media_id=' + image_id,
        contentType: 'application/x-www-form-urlencoded',
        success: function(data, text_status, xhr){
            $(row).remove();
        },
        error: function(data, text_status, xhr){
            alert('There was an error deleting the image. Please try again later.');
            $(row).removeClass('disabled');
        },
        complete: function(data, text_status, xhr){
        }
    });
}

function get_images_from_popup_box()
{
    
    var iFrame = document.getElementsByTagName('iframe')[1];
    var iFrameBody;
   
    if(iFrame.contentDocument) 
    {
        iFrameBody = iFrame.contentDocument.getElementsByTagName('body')[0];
    }
    else if(iFrame.contentWindow) 
    {
        iFrameBody = iFrame.contentWindow.document.getElementsByTagName('body')[0];
    }
    
    
    /*for(var j = 0; j <= 3; j++) {
         var inputscount = iFrameBody.getElementsByID('firstcount_'+j);
         alert(inputscount);
    }*/
    

    var inputs = iFrameBody.getElementsByTagName('input');
    //console.log(inputs);
    var selected_images = [];
    var selected_size = [];
    
    for(var i = 0; i < inputs.length; i++)
    {
        input = inputs[i];

        if(input.type == 'checkbox' && input.checked === true)
        {
            selected_images.push(input.value);
        }
        if(input.type == 'radio' && input.checked === true)
        {
            alert('if');
            selected_size.push(input.value);
        } else {
            alert('else');
            selected_size.push(' ');
        }
        
    }
    var resultval = selected_images+'-'+selected_size;

    return resultval;
}