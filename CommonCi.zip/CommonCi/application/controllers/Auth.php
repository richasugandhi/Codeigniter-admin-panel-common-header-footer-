<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends MY_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$this->data['page_title'] = 'Login | ' . $this->data['page_title'];

		$this->load->library('form_validation');

		$config = array(
	        array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'required'
	        ),
	        array(
                'field' => 'password',
                'label' => 'Password',
                'rules' => 'required',
	        )	        
		);

		$this->form_validation->set_rules($config);

		if ($this->form_validation->run() == TRUE){
            //login user and redirect
            $result = $this->user_model->get(array(
            	'user_email'	=> $this->input->post('email'),
            	'user_password'	=> md5($this->input->post('password')),
            ));
            if($result->num_rows() > 0){
            	$user = $result->result();
            	
            	$userdata = array(
			        'username'  => $user[0]->user_username,
			        'email'     => $user[0]->user_email,
			        'logged_in' => TRUE
				);
            	$this->session->set_userdata($userdata);
            	redirect('admin');
            }else{
            	$this->session->set_flashdata('login_error', '<div class="text-danger">Email or Password doesn\'t match.</div>');
            }            
        }

		$this->load->view('auth/login', $this->data);
	}

	public function register(){
		$this->data['page_title'] = 'Register | ' . $this->data['page_title'];

		$this->load->library('form_validation');

		$config = array(
	        array(
                'field' => 'email',
                'label' => 'Email',
                'rules' => 'required|unique'
	        ),
	        array(
                'field' => 'username',
                'label' => 'Username',
                'rules' => 'required',
	        )	        
		);

		$this->form_validation->set_rules($config);

		if ($this->form_validation->run() == TRUE){
            //login user and redirect
            redirect('admin');
        }

		$this->load->view('auth/register', $this->data);
	}

	public function logout(){
		$this->session->sess_destroy();
		redirect('/');
	}
}
