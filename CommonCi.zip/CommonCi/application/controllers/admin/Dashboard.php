<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends Admin_Controller {

	public function __construct(){
		parent::__construct();
	}

	public function index(){
		$this->render('admin/dashboard');
                $ipAddress = array(
                    'ip_address' => $_SERVER['REMOTE_ADDR']
                );
               /* $get = $this->visitors_model->get($ipAddress);
                $getResult = $get->result();
                if(empty($getResult)) {
                    $data = array(
                        'ip_address' => $_SERVER['REMOTE_ADDR'],
                        'count' => 1
                    );
                    $this->visitors_model->insert($data);
                } else {
                    $ipId = $getResult[0]->id;
                    $contVal = $getResult[0]->count;
                    $data = array(
                        'ip_address' => $_SERVER['REMOTE_ADDR']
                    );
                    $count = 0;
                    $totalcount = array(
                        'count' => $contVal+1
                    );
                    $this->visitors_model->update($totalcount, $ipId);
                }*/
	}
}
