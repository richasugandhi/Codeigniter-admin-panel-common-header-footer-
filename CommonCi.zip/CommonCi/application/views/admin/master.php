<?php
$this->load->view('admin/_parts/header');
?>
<div class="container-fluid">
	<div class="row">
		<div class="col-sm-3 col-md-2 sidebar">
			<ul class="nav nav-sidebar">
				<li class="<?php echo $active == 'dashboard' ? 'active' : ''; ?>" ><a href="">Dashboard</a></li>
				
			</ul>
		</div>
		<?php echo $main_content; ?>
	</div>
    <script>
        $(document).ready(function() {
            $('#menuPost').click(function() {
                
            });
        });
    </script>
</div>
<?php
$this->load->view('admin/_parts/footer');