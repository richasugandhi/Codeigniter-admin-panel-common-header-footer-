<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title><?php echo $page_title; ?></title>

        <link href="<?php echo site_url('assets/admin/css/bootstrap.min.css'); ?>" rel="stylesheet">
        
	<link href="<?php echo site_url('assets/admin/css/dashboard.css'); ?>" rel="stylesheet">
        
        <!-- Include external CSS. -->
        <link href="<?php echo site_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css" />
        
        <!-- Fastselect -->
        <link href="<?php echo site_url('assets/css/fastselect/fastselect.min.css'); ?>" rel="stylesheet" type="text/css" />
        
        
        <!-- This should be the first script since it inits base url -->
        <script type="text/javascript">
            var base_url = '<?php echo(base_url()); ?>';
        </script>
        
        <!-- jQuery -->
        <script src="<?php echo site_url('assets/admin/js/jquery.min.js'); ?>"></script>
        
        <!-- Bootstrap -->
        <script src="<?php echo site_url('assets/admin/js/bootstrap.min.js'); ?>"></script>
        
        <!-- Fastselect -->
        <script type="text/javascript" src="<?php echo site_url('assets/js/fastselect/fastselect.standalone.min.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo site_url('assets/js/fastselect/fastselect.min.js'); ?>"></script>
        
        <script type="text/javascript" src="<?php echo site_url('assets/js/push.min.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo site_url('assets/js/jquery.simpleWeather.js'); ?>"></script>
        <script type="text/javascript" src="<?php echo site_url('assets/js/jquery.simpleWeather.min.js'); ?>"></script>
        
        
        <link href="<?php echo site_url('assets/css/demo.css'); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo site_url('assets/css/flexslider.css'); ?>" rel="stylesheet" type="text/css" />
        <script>
            $.get({
                url: base_url + 'admin/pushnotification/getpushnotification',
                success: function(data, text_status, xhr)
                {
                    cleanText = data.replace(/<\/?[^>]+(>|$)/g, "");
                    var pushdata = cleanText.replace(/\"/g, "");
                    Push.create("Maliweb", {
                        body: pushdata,
                        icon: 'http://maliwebnetcdn-m0upn75d.stackpathdns.com/wp-content/news/images/2017/03/mwlogo.jpg',
                        url: 'http://www.maliweb.net/',
                        timeout: 3000,
                        onClick: function () {
                            window.focus();
                            this.close();
                        }
                    });
                }
            });
            
        </script>
        
        
        <!-- JS For Get the Weather -->
        <script type="text/javascript">
            
            /*$(document).ready(function() {
                $.simpleWeather({
                  location: 'Indore, India',
                  woeid: '',
                  unit: 'c',
                  success: function(weather) {
                    html = '<h2><i class="icon-'+weather.code+'"></i> '+weather.temp+'&deg;'+weather.units.temp+'</h2>';
                   // html += '<ul><li>'+weather.city+', '+weather.region+'</li>';
                   // html += '<li class="currently">'+weather.currently+'</li>';
                   // html += '<li>'+weather.wind.direction+' '+weather.wind.speed+' '+weather.units.speed+'</li></ul>';

                    $("#topbarweather").html(html);
                  },
                  error: function(error) {
                    $("#topbarweather").html('<p>'+error+'</p>');
                  }
                });
              });*/
              
        </script>
        <!-- JS For Get the Weather -->
        

        <!-- Custom JS File -->
        <script src="<?php echo site_url('assets/admin/js/script.js'); ?>"></script>
        <script src="<?php echo site_url('assets/admin/js/tinymce/tinymce.min.js'); ?>"></script>
        <script src="<?php echo site_url('assets/admin/js/tinymce/plugins/filemanager/plugin.min.js'); ?>"></script>
        <script>
        tinymce.init({
                selector: '#my_editor',
                plugins: [
                        'advlist autolink lists link charmap print jbimages preview anchor',
                        'searchreplace visualblocks code fullscreen',
                        'insertdatetime table contextmenu paste code emoticons filemanager media'
                ],
                toolbar: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link emoticons jbimages filemanager',
            content_css: '//www.tinymce.com/css/codepen.min.css',
        images_upload_url: '<?php echo(base_url() . "admin/media/do_upload/JSON"); ?>',
        file_picker_callback: function(cb, value, meta) {
            var input = document.createElement('input');
            input.setAttribute('type', 'file');
            input.setAttribute('accept', 'image/*');
                    
            // Note: In modern browsers input[type="file"] is functional without 
            // even adding it to the DOM, but that might not be the case in some older
            // or quirky browsers like IE, so you might want to add it to the DOM
            // just in case, and visually hide it. And do not forget do remove it
            // once you do not need it anymore.

            input.onchange = function() {
                var file = this.files[0];
                          
                // Note: Now we need to register the blob in TinyMCEs image blob
                // registry. In the next release this part hopefully won't be
                // necessary, as we are looking to handle it internally.
                var id = 'blobid' + (new Date()).getTime();
                var blobCache = tinymce.activeEditor.editorUpload.blobCache;
                var blobInfo = blobCache.create(id, file);
                blobCache.add(blobInfo);
                          
                // call the callback and populate the Title field with the file name
                        cb(blobInfo.blobUri(), {title: file.name});
                    };

                    input.click();
                },
                automatic_image_upload: true,
                relative_urls: false
            });
        </script>
        <script src="<?php echo(base_url() . 'assets/admin/js/tinymce/plugins/filemanager/plugin.min.js'); ?>"></script>
    </head>
    
    <body>
        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header" style="width: 20%;">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">MALI WEB</a><div id="topbarweather" style="color: white;"></div>
                    
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li>
                            <a href="#">Welcome, <?php echo($this->session->username); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('auth/logout'); ?>">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>