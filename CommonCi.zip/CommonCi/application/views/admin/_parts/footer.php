<script>
    tinymce.init({
            selector: '.commonclassFortinymce',
            plugins: [
                    'advlist autolink lists link charmap print jbimages preview anchor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime table contextmenu paste code emoticons filemanager'
            ],
            toolbar: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link emoticons',
            content_css: '//www.tinymce.com/css/codepen.min.css'
    });
</script>
<script type="text/javascript" src="http://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
 <link href="http://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
</body>
</html>