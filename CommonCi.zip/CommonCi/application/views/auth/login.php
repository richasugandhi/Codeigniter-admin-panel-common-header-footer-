<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <title><?php echo $page_title; ?></title>
        <!-- Bootstrap core CSS -->
        <link href="<?php echo site_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="<?php echo site_url('assets/css/signin.css'); ?>" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <form class="form-signin" method="post" action="">
                <h2 class="form-signin-heading">Please sign in</h2>
                <?php //echo validation_errors('<div class="text-danger">', '</div>'); ?>
                <?php //echo $this->session->flashdata('login_error'); ?>
                <div class="form-group">
                    <label for="inputEmail" class="sr-only">Email address</label>
                    <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email address" autofocus>
                </div>
                <div class="form-group">
                    <label for="inputPassword" class="sr-only">Password</label>
                    <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" >
                </div>
                <p class="text-right"><a href="#<?php //echo site_url('forget_password'); ?>">Forget Password</a></p>
                <p>Don't have an account? <a href="<?php echo site_url('register'); ?>">Register</a></p>
                <div class="form-action">
                    <button class="btn btn-primary" type="submit">Sign in</button>
                </div>
            </form>
            </div> <!-- /container -->
        </body>
    </html>