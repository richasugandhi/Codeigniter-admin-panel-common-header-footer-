<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
*/
class MY_Model extends CI_Model
{
	public $_tablename = '';
	public $_primary_key = '';

	public function __construct(){
		parent::__construct();
	}

	public function get($where = FALSE, $select = FALSE){
		if($select != FALSE){
			$this->db->select($select);
		}
		if(is_array($where)){
			$this->db->where($where);
		}
		$result = $this->db->get($this->_tablename);
		return $result;
	}

	public function insert($data){
		$this->db->insert($this->_tablename, $data);
		$insert_id = $this->db->insert_id();

   		return  $insert_id;
	}

	public function insert_batch($data){
		$this->db->insert_batch($this->_tablename, $data);
	}

	public function update($data, $id){
		$this->db->where(array(
			$this->_primary_key	=> $id
		));
		$this->db->update($this->_tablename, $data);
   		return  $id;
	}
        
        /*public function commongetdataselectonlyitemtype($typename,$where=''){
            $this->db->select($typename);
            if(!empty($where)){
                $this->db->where($where);
            }  
            $this->db->order_by('id','DESC');
            $this->db->group_by($typename); 
            $query = $this->db->get($this->_tablename);
            //echo $this->db->last_query();
            return $query->result_array();
        }*/
    
       /* public function commongetAlldata($where=''){
            if(!empty($where)){
                $this->db->where($where);
            }        
            $query = $this->db->get($this->_tablename);
            return $query->result_array();
        }*/
}