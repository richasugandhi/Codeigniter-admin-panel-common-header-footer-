<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {
	
	public $data = array();

	public function __construct(){
		parent::__construct();

		$this->data['page_title'] = 'Admin';
	}

	protected function render($main_content, $template = 'master'){
		$this->data['main_content'] = $this->load->view($main_content, $this->data, TRUE);
		$this->load->view($template, $this->data);
	}

	protected function auth_check_redirect(){
		if($this->session->has_userdata('logged_in') == FALSE){
			redirect(site_url('login'));
		}
	}

}
