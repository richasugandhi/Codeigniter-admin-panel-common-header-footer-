<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Controller extends MY_Controller {
	
	public function __construct(){
		parent::__construct();

		$this->data['page_title'] = 'Admin | Maliweb';
		$this->data['active'] = $this->uri->segment(2);

		$this->auth_check_redirect();
	}

	protected function render($main_content, $template = 'admin/master'){
		$this->data['main_content'] = $this->load->view($main_content, $this->data, TRUE);
		$this->load->view($template, $this->data);
	}

}
