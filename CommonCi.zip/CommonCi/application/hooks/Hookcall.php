<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Hookcall extends CI_Controller {
    public function tempfunction(){
        echo "Good Morning, Everyone";
    }
}
?>