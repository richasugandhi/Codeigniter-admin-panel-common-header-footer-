<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
*/
class User_Model extends MY_Model
{
	public $_tablename = 'users';
	public $_primary_key = 'user_id';

	public function __construct(){
		parent::__construct();
	}
}