<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
* 
*/
class Visitors_model extends MY_Model
{
	public $_tablename = 'visitors';
	public $_primary_key = 'id';

	public function __construct()
	{
		parent::__construct();
	}
        
        
        
}
?>